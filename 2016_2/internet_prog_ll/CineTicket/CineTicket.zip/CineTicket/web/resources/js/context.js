(function() {
    'use strict';
    
    
    /* VARIABLES */
    var btnSingIn = document.getElementById('btnsingin');
    var btnSingUp = document.getElementById('btnsingup');
    var singinContent = document.getElementById('singin');
    var singupContent = document.getElementById('singup');
    
    
    /* FUNCTIONS */
    function showSingIn() {
        singinContent.className = 'singin content-login';
        singupContent.className = 'singup content-login displaynone';
    };

    function showSingUp() {                    
        singupContent.className = 'singup content-login';
        singinContent.className = 'singin content-login displaynone';
    };
    
    
    /* CONSTRUCTOR */
    (function Contructor() {
        btnSingIn.addEventListener('click', function(e) {
            e.preventDefault();
            showSingIn();
        });                

        btnSingUp.addEventListener('click', function(e) {
            e.preventDefault();
            showSingUp();
        });
    })(); 
})();