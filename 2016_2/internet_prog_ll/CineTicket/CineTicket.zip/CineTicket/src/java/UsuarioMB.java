import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;

@Named
@SessionScoped
public class UsuarioMB implements Serializable {
    // ATTRIBUTES
    private boolean logged;
    private Usuario user;
    private List<Usuario> listUsers;
    
    
    // CONSTRUCTOR
    public UsuarioMB() {
        logged = false;
        listUsers = new ArrayList<>();
        
        listUsers.add(new Usuario("robsongajunior", "junior", "123", true));
        listUsers.add(new Usuario("helio", "helio", "helio", true));        
        listUsers.add(new Usuario("beto", "betao", "beto123", false));
        listUsers.add(new Usuario("felipe", "moura", "felipe123", false));
        listUsers.add(new Usuario("jaydson", "alemao", "123", false));
        
        user = new Usuario();
    }
    
    
    // METHODS
    public boolean isLogged() {
        return logged;
    }
    
    
    // GETTERS
    public Usuario getUser() {
        return user;
    }
    
    public List<Usuario> getListUsers() {
        return listUsers;
    }

       
    // SETTERS
    public void setUser(Usuario user) {
        this.user = user;
    }
    
    public void setListUsers(List<Usuario> listUsers) {
        this.listUsers = listUsers;
    }
    
    
    // ACTIONS
    public String singup() {
        listUsers.add(user);
        
        this.user = new Usuario();
        
        return("index");
    }
    
    public String delete(Usuario user)  {
        for(Usuario u: listUsers) {
            if(u.equals(user)) {
                listUsers.remove(u);
                break;
            }
        }    
        
        return("users?faces-redirect=true");
    }
    
    public String update() {        
        return("profile?faces-redirect=true");
    }
    
    public String singin() {
        String indexRedirect = "/index?faces-redirect=true";
        
        for(Usuario u: listUsers) {
            if(u.equals(user)) {
                setUser(u);
                logged = true;
                
                if(u.isAdmin()) {
                    return("admin" + indexRedirect); 
                } else {
                    return("user" + indexRedirect); 
                }
            }
        }        
        
        FacesContext ctx = FacesContext.getCurrentInstance();
        FacesMessage msg = new FacesMessage(
                FacesMessage.SEVERITY_ERROR,
                "Login inválido!", "User or password invalid. Please, try again."
        );

        ctx.addMessage("idMensagem", msg);

        return ("/faces/index?faces-redirect=true");
    }

    public String logout() {
        logged = false;
        FacesContext ctx = FacesContext.getCurrentInstance();
        
        ctx.getExternalContext().invalidateSession();
        
        return ("/faces/index?faces-redirect=true");
    }
}