import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;

@Named
@SessionScoped
public class MovieMB implements Serializable {
    // ATTRIBUTES
    private List<Movie> listMovies;
    private Movie movie;
    
    
    // CONSTRUCTOR
    public MovieMB() {
        listMovies = new ArrayList<>();
        
        listMovies.add(new Movie("Fast and Furious 1", "02/07/1998", "Action", "My fucking description"));
        listMovies.add(new Movie("Mr. Robot", "02/07/2014", "Action and Fiction", "Security and Fucking E-Corp"));
        listMovies.add(new Movie("Matrix", "02/07/2000", "Fiction", "Fucking hacker"));
        listMovies.add(new Movie("American Snipper", "02/07/2015", "War", "War description"));
        
        this.movie = new Movie();
    }
    
    // GETTERS
    public Movie getMovie() {
        return movie;
    }
    
    public List<Movie> getListMovies() {
        return listMovies;
    }

       
    // SETTERS
    public void setMovie(Movie movie) {
        this.movie = movie;
    }
    
    public void setListMovies(List<Movie> listMovies) {
        this.listMovies = listMovies;
    }
    
    
    // ACTIONS
    public String register() {
        listMovies.add(movie);
        
        this.movie = new Movie();
        
        return("index?faces-redirect=true");
    }
    
    public String delete(Movie movie)  {
        for(Movie m: listMovies) {
            if(m.equals(movie)) {
                listMovies.remove(m);
                break;
            }
        }    
        
        return("index?faces-redirect=true");
    }
    
    public String toEdit(Movie movie) {
        this.movie = movie;
        return("movie-edit?faces-redirect=true");
    }
    
    public String aboutMovie(Movie movie) {
        this.movie = movie;
        return("movie?faces-redirect=true");
    }
    
    public String update() {
        this.movie = new Movie();
        return("index?faces-redirect=true");
    }
}