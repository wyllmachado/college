import java.io.Serializable;
import java.util.Objects;

public class Movie implements Serializable {
    // ATTRIBUTES
    private String name;
    private String date;
    private String genery;
    private String description;
        
    
    // CONTRUCTOR
    public Movie() {}     
    public Movie(
            String name,
            String date,
            String genery,
            String description
    ) {
        this.name = name;
        this.date = date;
        this.genery = genery;
        this.description = description;
    }

    
    // GETTERS
    public String getName() {
        return name;
    }
    
    public String getDate() {
        return date;
    }

    public String getGenery() {
        return genery;
    }
    
    public String getDescription() {
        return description;
    }
       
    
    // SETTERS
    public void setName(String name) {
        this.name = name;
    }
    
    public void setDate(String date) {
        this.date = date;
    }
    
    public void setGenery(String genery) {
        this.genery = genery;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
        
    
    // GENERIC METHODS
    
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        
        if (obj == null) {
            return false;
        }
        
        if (getClass() != obj.getClass()) {
            return false;
        }
        
        final Movie other = (Movie) obj;
        
        if (
            !Objects.equals(this.name, other.name) ||
            !Objects.equals(this.date, other.date)
        ) {
            return false;
        }
        
        return true;
    }
}