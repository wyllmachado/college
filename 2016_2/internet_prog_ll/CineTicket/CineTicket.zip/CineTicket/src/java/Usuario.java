import java.io.Serializable;
import java.util.Objects;

public class Usuario implements Serializable {
    // ATTRIBUTES
    private String name;
    private String nick;
    private String password;
    private boolean admin;
    
    
    // CONTRUCTOR
    public Usuario() {}     
    public Usuario(
            String name,
            String nick,
            String password,
            boolean admin
    ) {
        this.name = name;
        this.nick = nick;
        this.password = password;
        this.admin = admin;
        
        System.out.println("# Admin" + admin);
    }

    
    // GETTERS
    public String getName() {
        return name;
    }
    
    public String getNick() {
        return nick;
    }

    public String getPassword() {
        return password;
    }
    
    public String getAdminStatusString() {
        if(admin) {
            return "true";
        }
        
        return "false";
    }
   
    
    // SETTERS
    public void setName(String name) {
        this.name = name;
    }
    
    public void setNick(String nick) {
        this.nick = nick;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public void setAdmin(boolean admin) {
        this.admin = admin;
    }
    
    
    // GENERIC METHODS
    public boolean isAdmin() {
        return admin;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        
        if (obj == null) {
            return false;
        }
        
        if (getClass() != obj.getClass()) {
            return false;
        }
        
        final Usuario other = (Usuario) obj;
        
        if (
            !Objects.equals(this.nick, other.nick) ||
            !Objects.equals(this.password, other.password)
        ) {
            return false;
        }
        
        return true;
    }
}