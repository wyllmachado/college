import java.io.IOException;
import javax.inject.Inject;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

@WebFilter(
    filterName = "FilterAccess",
    urlPatterns = {
        "/faces/admin/*",
        "/faces/user/*"
    }
)
public class FilterAccess implements Filter {
    private String pattern = "faces/(admin|user)";
    private Pattern rgx = Pattern.compile(pattern);    
    
    
    @Inject 
    private UsuarioMB usuarioMB;    
    
    
    @Override
    public void doFilter(
            ServletRequest request,
            ServletResponse response,
            FilterChain chain
    ) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;
        
        Matcher matchRegex = rgx.matcher(req.getRequestURI());
        System.out.println("# [CineTicket] find " + matchRegex.find());
        
        if (usuarioMB != null && usuarioMB.isLogged()) {
            if(
                usuarioMB.getUser().isAdmin() &&
                matchRegex.group(0).compareTo("faces/admin" ) != 0 
            ) {
                System.out.println("# [CineTicket] Admin user, redirecting to admin index page");
                resp.sendRedirect(req.getContextPath() + "/faces/admin/index.xhtml");
            } else if(
                usuarioMB.getUser().isAdmin() != true &&
                matchRegex.group(0).compareTo("faces/user" ) != 0 
            ) {
                System.out.println("# [CineTicket] Not admin user, redirecting to user index page");
                resp.sendRedirect(req.getContextPath() + "/faces/user/index.xhtml");
            } else {            
                chain.doFilter(request, response);
            }
        } else {
            resp.sendRedirect(req.getContextPath() + "/faces/index.xhtml");
        }
    }
    
    
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    
    @Override
    public void destroy() {
    }
}