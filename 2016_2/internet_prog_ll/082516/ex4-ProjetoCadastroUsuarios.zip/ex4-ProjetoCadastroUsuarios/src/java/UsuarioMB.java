
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

@Named
@SessionScoped
public class UsuarioMB implements Serializable {
    private Usuario usuario;
    private List<Usuario> listaUsuarios;

    public UsuarioMB() {
        usuario = new Usuario();
        listaUsuarios = new ArrayList<Usuario>();
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public List<Usuario> getListaUsuarios() {
        return listaUsuarios;
    }

    public void setListaUsuarios(List<Usuario> listaUsuarios) {
        this.listaUsuarios = listaUsuarios;
    }
    
    public String addUsuario(){
        listaUsuarios.add(usuario);
        this.usuario = new Usuario();
        return("usuarios"); //para Repeat, altere para usuariosRepeat
    }
}
