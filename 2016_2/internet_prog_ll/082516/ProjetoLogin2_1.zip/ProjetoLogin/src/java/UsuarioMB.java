import java.util.ArrayList;
import java.util.List;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

/**
 *
 * @author lhries
 */
@Named(value = "usuarioMB")
@RequestScoped
public class UsuarioMB {
    private List<Usuario> listaUsuarios;
    private Usuario usuario;
    
    /**
     * Creates a new instance of UsuarioMB
     */
    public UsuarioMB() {
        usuario = new Usuario();
        
        listaUsuarios = new ArrayList<>();
        listaUsuarios.add(new Usuario("fulano","123"));
        listaUsuarios.add(new Usuario("sicrano","123"));
        listaUsuarios.add(new Usuario("beltrano","123"));
        listaUsuarios.add(new Usuario("teste","123"));
        listaUsuarios.add(new Usuario("admin","123"));
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
      
    
    //Action
    public String realizaLogin(){
        for(Usuario u: listaUsuarios){
            if(u.equals(usuario))
                return("usuario");            
        }
        FacesContext contexto = FacesContext.getCurrentInstance();
        FacesMessage mensagem = new FacesMessage(
                FacesMessage.SEVERITY_ERROR, 
                "Usuario ou senha inválido!", 
                "Você precisa se autenticar corretamente!");
        contexto.addMessage("msgErro", mensagem);
        return "login";
    }
}
