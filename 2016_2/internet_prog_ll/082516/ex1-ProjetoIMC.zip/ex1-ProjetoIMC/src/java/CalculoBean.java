
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;




@Named (value = "calculoBean")
@RequestScoped
public class CalculoBean {
    private Float altura;
    private Float peso;
    private Float imc;

    public CalculoBean() {
    }

    public Float getAltura() {
        return altura;
    }

    public void setAltura(Float altura) {
        this.altura = altura;
    }

    public Float getPeso() {
        return peso;
    }

    public void setPeso(Float peso) {
        this.peso = peso;
    }

    public Float getImc() {
        return imc;
    }
    
    public void calculaImc()
    {
        imc = peso/(altura*altura);
    }
    
}
