/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

/**
 *
 * @author lhries
 */
@Named(value = "pessoaMB")
@RequestScoped
public class PessoaMB {
    private String nome;

   
    public PessoaMB() {
        
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public String verificaTamanho(){
        if(nome.length() > 3){
            //Sucesso - vai pra proxima pagina
            return("hello");
        }
        else
        {
            //Insucesso - fica na mesma pagina
            nome="";
            FacesContext contexto = FacesContext.getCurrentInstance();
            FacesMessage mensagem = new FacesMessage(
                    FacesMessage.SEVERITY_ERROR, 
                    "Entrada Invalida!", 
                    "Nome tem que ter no minimo quatro letras!");
            contexto.addMessage(null, mensagem);
            System.out.println("Nome tem que ter no minimo quatro letras");
            return("formulario");
        }
    }
    
    
}
