import java.util.ArrayList;
import java.util.List;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;

/**
 *
 * @author lhries
 */
@Named(value = "usuarioMB")
@RequestScoped
public class UsuarioMB {
    private List<Usuario> listaUsuarios;
    private Usuario usuario;
    private String mensagemErro;
    /**
     * Creates a new instance of UsuarioMB
     */
    public UsuarioMB() {
        usuario = new Usuario();
        
        listaUsuarios = new ArrayList<>();
        listaUsuarios.add(new Usuario("fulano","123"));
        listaUsuarios.add(new Usuario("sicrano","123"));
        listaUsuarios.add(new Usuario("beltrano","123"));
        listaUsuarios.add(new Usuario("teste","123"));
        listaUsuarios.add(new Usuario("admin","123"));
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public String getMensagemErro() {
        return mensagemErro;
    }
    
    
    
    //Action
    public String realizaLogin(){
        for(Usuario u: listaUsuarios){
            if(u.equals(usuario))
                return("usuario");            
        }
        mensagemErro="Usuario ou senha invalido!";
        return "login";
    }
}
